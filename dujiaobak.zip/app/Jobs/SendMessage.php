<?php

namespace App\Jobs;

use App\Models\User;
use GuzzleHttp\Client;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;

class SendMessage implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * 任务最大尝试次数。
     *
     * @var int
     */
    public $tries = 2;

    /**
     * 任务运行的超时时间。
     *
     * @var int
     */
    public $timeout = 30;

    private $content;


    public function __construct(string $content){
        $this->content = $content;
    }

    public function handle(){
        $res = DB::select("SELECT * FROM users where 1 = 1");
        $bot = new \TelegramBot\Api\Client(dujiaoka_config_get("bottoken"));
        foreach ($res as $item){
            try{
                $bot->sendMessage($item->uid,$this->content);
            }catch (\Exception $e){

            }
        }
    }
}
