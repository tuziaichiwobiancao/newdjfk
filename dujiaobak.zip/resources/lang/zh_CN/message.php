<?php 
return [
    'labels' => [
        'Message' => 'Message',
        'message' => 'Message',
    ],
    'fields' => [
        'message' => '消息内容',
        'addtime' => '添加时间',
    ],
    'options' => [
    ],
];
