<?php 
return [
    'labels' => [
        'Recharge' => 'Recharge',
        'recharge' => 'Recharge',
    ],
    'fields' => [
        'uid' => '所属用户id',
        'orderno' => '订单号',
        'money' => '订单金额',
        'sign' => 'sign',
        'status' => '订单状态:-1=已取消,0=待支付,1=已支付',
        'addtime' => '添加时间',
        'paytime' => '支付时间',
    ],
    'options' => [
    ],
];
