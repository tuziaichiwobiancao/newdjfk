<?php 
return [
    'labels' => [
        'User' => 'User',
        'user' => 'User',
    ],
    'fields' => [
        'uname' => '用户名',
        'nick' => '用户昵称',
        'money' => '余额',
        'points' => '积分',
        'upid' => '上一级id',
        'addtime' => '添加时间',
        'updatetime' => '更新时间',
    ],
    'options' => [
    ],
];
