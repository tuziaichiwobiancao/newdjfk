<?php 
return [
    'labels' => [
        'Button' => 'Button',
        'button' => 'Button',
    ],
    'fields' => [
        'tips' => '注释',
        'keyword' => '关键词',
        'func' => '功能',
        'content' => '回复内容',
        'parse' => '模式:HTML=HTML,MarkDown=MarkDown',
        'disable' => '链接预览:0=关闭,1=开启',
        'button' => '按钮组',
        'addtime' => '添加时间',
    ],
    'options' => [
    ],
];
