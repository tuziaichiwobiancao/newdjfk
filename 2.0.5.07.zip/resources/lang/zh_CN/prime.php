<?php 
return [
    'labels' => [
        'Prime' => 'Prime',
        'prime' => 'Prime',
    ],
    'fields' => [
        'uid' => '用户id',
        'order' => '订单号',
        'username' => '要充值的用户名',
        'month' => '月份:3,6,12',
        'status' => '状态:-1=手动充值,0=待充值,1=自动充值',
        'addtime' => '添加时间',
    ],
    'options' => [
    ],
];
