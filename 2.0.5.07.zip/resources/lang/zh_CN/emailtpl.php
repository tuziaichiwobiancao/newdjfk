<?php

return [
    'labels' => [
        'Emailtpl' => '邮件模板',
        'emailtpl' => '邮件模板',
    ],
    'fields' => [
        'tpl_name' => '邮件标题',
        'tpl_content' => '邮件内容',
        'tpl_token' => '邮件标识',
    ],
    'options' => [
    ],
];
